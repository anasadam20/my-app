import React from 'react'
import loginimg from '../img/login-img.png'
import { Link, useMatch, useResolvedPath } from 'react-router-dom';

const Loginpage = () => {
  return (
    <>
    <section className='inner-banner'>
      <div class="container">
        <p> <a href="/">Home</a>&gt; Sign Up</p>
        <h2>Sign Up</h2>
      </div>
    </section>
    <section className='login-container'>
      <div className="container">
           <div className="row">
            <div className="col-md-10 m-auto">
              <div className="card">
              <div className="row align-items-center">
                <div className="col-md-6">
                <div className='left-login-content'>
                   <h4>Grow With learn4tomorrows</h4>
                   <div className='img-content'>
                      <img className='banner-img' src={loginimg} alt="banner-img" />
                         <h6>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Pariatur.</h6>
                   </div>
                </div>
              </div>
              <div className="col-md-6">
                <div className='right-login-content'>
                   <h4>Sign Up</h4>
                   <div className="form">
                      <form action="#">
                          <div className="form-controls">
                            <input type="text" placeholder='Enter Name' />
                          </div>
                          <div className="form-controls">
                            <input type="text" placeholder='Enter Email Address' />
                          </div>
                          <div className="form-controls">
                            <input type="password" placeholder='Enter Password' />
                          </div>
                          <div className="form-controls">
                            <input type="password" placeholder='Enter Confirm Password' />
                          </div>
                          <div className='d-flex justify-content-end form-controls'>
                             <a href="#" className='custom-btn login-btn'>Submit</a>
                          </div>
                      </form>
                   </div>
                </div>
              </div>
                </div>
              </div>
              
            </div>
          </div>
      </div>
    </section>
    </>
  )
}

export default Loginpage